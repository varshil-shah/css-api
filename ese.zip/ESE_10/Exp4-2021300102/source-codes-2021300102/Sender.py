import socket
import rsa
from Crypto.Cipher import AES
import os

# Diffie-Hellman parameters
p = 23
g = 5
a = 6
global PUBLIC_KEY_B
global PUBLIC_KEY_A
global secret_key

def dh_encrypt(message,secret_key):
    encrypted_message = ""
    for letter in message:
        encrypted_message += chr(ord(letter)+secret_key)
    return encrypted_message

def dh_key_exchange():
    global PUBLIC_KEY_B
    global PUBLIC_KEY_A
    public_key_a = (g**a) % p
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.connect(("localhost", 3333))
    server.send(f"{public_key_a}".encode('utf-8'))
    public_key_b = server.recv(1024).decode('utf-8')
    PUBLIC_KEY_B = int(public_key_b)
    server.close()
    global secret_key
    secret_key = (PUBLIC_KEY_B**a) % p
    print(f"Secret key: {secret_key}")

def send_message(message):
    # Encrypt the message
    dh_encrypt_message = dh_encrypt(message, secret_key)
    # # Send the encrypted symmetric key and the encrypted message to the receiver
    receiver_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    receiver_socket.connect(("localhost", 3333))
    receiver_socket.send(f"{dh_encrypt_message}".encode('utf-8'))
    receiver_socket.close()

def main():
    identity = input("Enter your identity: ")
    while True:
        print("1. Generate Diffie-Hellman Key")
        print("2. Send Message")
        print("3. Exit")
        choice = input("Enter your choice: ")
        
        if choice == "1":
            dh_key_exchange()
            print("Exchanged key successfully")
        elif choice == "2":
            message = input("Enter message: ")
            send_message(message)
        elif choice == "3":
            break

if __name__ == "__main__":
    main()
