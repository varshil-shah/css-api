import socket
import rsa
from Crypto.Cipher import AES

# Diffie-Hellman parameters
p = 23
g = 5
b = 15
global PUBLIC_KEY_B
global PUBLIC_KEY_A
global secret_key

def dh_decrypt(message, secret_key):
    decrypted_message = ""
    for letter in message:
        decrypted_message += chr(ord(letter)-secret_key)
    return decrypted_message

def dh_key_exchange():
    global PUBLIC_KEY_B
    global PUBLIC_KEY_A
    public_key_b = (g**b) % p
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("localhost", 3333))
    #listen for public key A
    server.listen(1)
    conn, addr = server.accept()
    public_key_a = conn.recv(1024).decode('utf-8')
    PUBLIC_KEY_A = int(public_key_a)
    conn.send(f"{public_key_b}".encode('utf-8'))
    server.close()
    global secret_key
    secret_key = (PUBLIC_KEY_A**b) % p
    print(f"Secret key: {secret_key}")


def receive_message():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("127.0.0.1", 3333))
    server.listen()
    print("Waiting for messages...")

    client_socket, addr = server.accept()
    data = client_socket.recv(1024)
    message = dh_decrypt(data.decode('utf-8'), secret_key)
    print(f"Received message: {message}")
    client_socket.close()
    server.close()

def main():
    identity = input("Enter your identity: ")

    while True:
        print("1. Generate Diffie-Hellman Key")
        print("2. Wait for Message")
        print("3. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            dh_key_exchange()
            print("Exchanged key successfully")
        elif choice == "2":
            receive_message()
        elif choice == "3":
            break

if __name__ == "__main__":
    main()
