import socket

HOST = '127.0.0.1'
PORT = 4444

# Dictionary to store public keys associated with identities
public_keys = {}

def handle_client(client_socket):
    try:
        while True:
            request = client_socket.recv(1024).decode('utf-8')
            print(f"Received request: {request}")
            if not request:
                continue
            
            if request.startswith("REGISTER"):
                _, identity, public_key_n, public_key_e = request.split(',')
                public_keys[identity] = (public_key_n, public_key_e)
                client_socket.send(f"{identity} registered successfully.".encode('utf-8'))
            
            elif request.startswith("GET_KEY"):
                _, identity = request.split()
                if identity in public_keys:
                    n, e = public_keys[identity]
                    client_socket.send(f"{n} {e}".encode('utf-8'))
                else:
                    client_socket.send("Identity not found.".encode('utf-8'))
            
            else:
                client_socket.send("Invalid request.".encode('utf-8'))
            break
    
    except Exception as e:
        print(f"Error: {e}")
    
    finally:
        client_socket.close()

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        print(f"Server listening on {HOST}:{PORT}")
        
        while True:
            conn, addr = s.accept()
            print("Connected by", addr)
            handle_client(conn)

if __name__ == "__main__":
    main()
