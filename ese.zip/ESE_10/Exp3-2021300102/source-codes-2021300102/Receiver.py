import socket
import rsa
from Crypto.Cipher import AES

# RSA keys for the receiver
n=33
e=3
d=7
def helper(text):
    # 00 -> A, 01 -> B, 02 -> C, ..., 25 -> Z
    return "".join([chr(int(text[i:i+2])+65) for i in range(0, len(text), 2)])
def decrypt(ciphertext, key):
    plaintext = ""
    i = 0
    for letter in ciphertext:
        double_shift = ord(letter)-65 - (ord(key[i%len(key)])-65)
        double_shift = double_shift % 26
        plaintext += chr(double_shift + 65)
        i += 1
    return plaintext

def rsa_decrypt(encrypted_message, n, d):
    decrypted_message = ""
    for letter in encrypted_message.split(","):
        if letter:
            decrypted_message += str(pow(int(letter), d, n))
    return decrypted_message

def register_identity(identity, public_key_n, public_key_e):
    third_party = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    with third_party:
        third_party.connect(("127.0.0.1", 4444))
        registration_message = f"REGISTER,{identity},{public_key_n},{public_key_e}"
        third_party.send(registration_message.encode('utf-8'))
        response = third_party.recv(1024).decode('utf-8')
        print(response)

def receive_message():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("127.0.0.1", 3333))
    server.listen()
    print("Waiting for messages...")

    client_socket, addr = server.accept()
    data = client_socket.recv(1024)
    rsa_cipher_key, rsa_cipher_message = data.decode('utf-8').split("+")
    print(f"Received RSA cipher key: {rsa_cipher_key}")
    print(f"Received RSA cipher message: {rsa_cipher_message}")
    cipher_key = rsa_decrypt(rsa_cipher_key, n, d)
    cipher_key = helper(cipher_key)
    print(f"Decrypted cipher key: {cipher_key}")
    cipher_message = rsa_decrypt(rsa_cipher_message, n, d)
    cipher_message = helper(cipher_message)
    message = decrypt(cipher_message, cipher_key)

    print(f"Received message: {message}")

    client_socket.close()
    server.close()

def main():
    identity = input("Enter your identity: ")

    while True:
        print("1. Register Identity")
        print("2. Wait for Message")
        print("3. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            register_identity(identity, "33", "3")
        elif choice == "2":
            receive_message()
        elif choice == "3":
            break

if __name__ == "__main__":
    main()
