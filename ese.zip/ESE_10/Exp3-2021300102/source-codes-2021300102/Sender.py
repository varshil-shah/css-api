import socket
import rsa
from Crypto.Cipher import AES
import os

# RSA keys for the sender
n=33
e=3
d=7
symetric_key= "MYKEY"
def helper(text):
    # A->00, B->01, C->02, ..., Z->25
    return "".join([f"{ord(letter)-65:02}" for letter in text])

def rsa_encrypt(message, n, e):
    encrypted_message = ""
    for letter in message:
        encrypted_message += str(pow(int(letter), e, n))+","
    
    return encrypted_message


def encrypt(plaintext, key):
    ciphertext = ""
    i = 0
    for letter in plaintext:
        double_shift = ord(letter)-65 + ord(key[i%len(key)])-65
        double_shift = double_shift % 26
        ciphertext += chr(double_shift + 65)
        i += 1
    return ciphertext
def register_identity(identity, public_key_n, public_key_e):
    third_party = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    with third_party:
        third_party.connect(("127.0.0.1", 4444))
        registration_message = f"REGISTER,{identity},{public_key_n},{public_key_e}"
        third_party.send(registration_message.encode('utf-8'))
        response = third_party.recv(1024).decode('utf-8')
        print(response)

def send_message(receiver_identity, message, key):
    third_party = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    third_party.connect(("localhost", 4444))
    third_party.send(f"GET_KEY {receiver_identity}".encode('utf-8'))
    receiver_msg= third_party.recv(1024).decode('utf-8')
    receiver_public_key_n, receiver_public_key_e = receiver_msg.split()
    print("Receiver Public Key: ", receiver_public_key_n, receiver_public_key_e)
    third_party.close()
    # Encrypt the message with the symmetric key
    cipher_message= encrypt(message, key)
    rsa_cipher_message = rsa_encrypt(helper(cipher_message), int(receiver_public_key_n), int(receiver_public_key_e))
    rsa_cipher_key = rsa_encrypt(helper(key), n, e)
    # # Send the encrypted symmetric key and the encrypted message to the receiver
    receiver_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    receiver_socket.connect(("localhost", 3333))
    receiver_socket.send(f"{rsa_cipher_key}+{rsa_cipher_message}".encode('utf-8'))
    receiver_socket.close()

def main():
    identity = input("Enter your identity: ")
    while True:
        print("1. Register Identity")
        print("2. Send Message")
        print("3. Exit")
        choice = input("Enter your choice: ")
        
        if choice == "1":
            register_identity(identity,"33","3")
        elif choice == "2":
            receiver_identity = input("Enter receiver identity: ")
            message = input("Enter message: ")
            key = input("Enter symmetric key: ")
            send_message(receiver_identity, message, key)
        elif choice == "3":
            break

if __name__ == "__main__":
    main()
