dictionary = ["ISTHISKEY","MYKEY","NOTTHISKEY","KEY","WHYTHISKEY","OKKEY",""]
plaintext = "HELLOONAMTHISATTACKWILLBREAKTHECIPHER"
def decrypt(ciphertext, key):
    plaintext = ""
    i = 0
    for letter in ciphertext:
        double_shift = ord(letter)-65 - (ord(key[i%len(key)])-65)
        double_shift = double_shift % 26
        plaintext += chr(double_shift + 65)
        i += 1
    return plaintext

def crack(ciphertext):
    for key in dictionary:
        if decrypt(ciphertext, key) == plaintext:
            print("Key found:",key)
            print("Decrypted:",decrypt(ciphertext,key)) 
            return key
    return "Key not found"

def encrypt(plaintext, key):
    ciphertext = ""
    i = 0
    for letter in plaintext:
        double_shift = ord(letter)-65 + ord(key[i%len(key)])-65
        double_shift = double_shift % 26
        ciphertext += chr(double_shift + 65)
        i += 1
    return ciphertext

ciphertext = encrypt(plaintext, "MYKEY")
print("Plaintext:",plaintext)
print("Ciphertext:",ciphertext)
print("Cracked:",crack(ciphertext))
