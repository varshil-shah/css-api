import json
data = json.load(open("Exp1/Attack/bigrams.json"))
# data is a list of bigrams with their frequencies, convert it to a dictionary
bigram = {bigram: freq for bigram, freq in data}
print("Bigrams:\n", bigram)
cipher_text = "MNSTEQCHPUHGNFITUHDEMRCYTIHVTEGPNEOQBFFZHABUAHKYRLHWPZKNALFBIAUNZFADPSWDQTVDOQTOQPZFPFUADRIEBNEPUPOQBFFZNPTKFSBNIEBNITUHFBQNNCKTWFETPUNLSPDOGPNENLIZUIETSTREQTUHURDEMCTKRCMNSTOIFZELBAIZ"
# The bigram frequencies are already sorted in descending order
def clean(text):
    new_text = ""
    for i in range(0, len(text)-1, 2):
        new_text += text[i] + text[i+1] + "+"
    return new_text
def get_bigrams(text):
    text = text.upper()
    bigrams = {}
    for i in range(0, len(text)-1, 2):
        bigram = text[i] + text[i+1]
        if bigram in bigrams:
            bigrams[bigram] += 1
        else:
            bigrams[bigram] = 1

    bigrams = dict(sorted(bigrams.items(), key=lambda item: item[1], reverse=True))
    print("Bigrams:\n", bigrams)
    return bigrams

print("Cipher Text:", cipher_text)
bigrams_cipher = get_bigrams(cipher_text)
cipher_text = clean(cipher_text)

for x in bigrams_cipher:
    print("Decrypt for bigram", x)
    for c in bigram:
        #replace x with c in cipher text and print c in a different color in the terminal
        cipher_text = cipher_text.replace(x, c.lower())
        print(cipher_text)
        str=input("Do you accept this substitution with "+c+"? (y/n)")
        if str == "y":
            bigram.pop(c)
            break
        else:
            cipher_text = cipher_text.replace(c.lower(), x)
        print()

