#known plaintext attack on hill cipher
#n=3 #size of the key matrix
import numpy as np
plaintext1="ACT"
plaintext2="CAT"
plaintext3="DOG"

cipher1="POH"
cipher2="FIN"
cipher3="WLY"

def get_x(determinant):
    for i in range(26):
        if (determinant * i) % 26 == 1:
            print(i)
            return i
    return -1

def get_matrix(plaintext,cipher):
    inv_plaintext=np.linalg.inv(plaintext)
    #round to the nearest integer
    inv_plaintext=np.ceil(inv_plaintext)
    x=get_x(np.linalg.det(inv_plaintext))
    inv_plaintext=np.mod(inv_plaintext*x,26)
    key_matrix=np.dot(cipher,inv_plaintext)
    key_matrix=np.mod(key_matrix,26)
    return key_matrix



plaintext=np.array([[ord(plaintext1[0])-65,ord(plaintext2[0])-65,ord(plaintext3[0])-65],
                    [ord(plaintext1[1])-65,ord(plaintext2[1])-65,ord(plaintext3[1])-65],
                    [ord(plaintext1[2])-65,ord(plaintext2[2])-65,ord(plaintext3[2])-65]])
print(plaintext)

cipher=np.array([[ord(cipher1[0])-65,ord(cipher2[0])-65,ord(cipher3[0])-65],
                    [ord(cipher1[1])-65,ord(cipher2[1])-65,ord(cipher3[1])-65],
                    [ord(cipher1[2])-65,ord(cipher2[2])-65,ord(cipher3[2])-65]])
print(cipher)

key_matrix=get_matrix(plaintext,cipher)

def convert_key_to_string(key_matrix):
    key=""
    #convert key to integer first
    for i in range(3):
        for j in range(3):
            #ceil to get the nearest integer
            key_int=int(np.ceil(key_matrix[i][j]))
            key+=chr(key_int+65)
    return key

print(convert_key_to_string(key_matrix))
