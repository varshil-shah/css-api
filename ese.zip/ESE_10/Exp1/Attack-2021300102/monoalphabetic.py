# Frequency Analysis Attack on Monoalphabetic Cipher
cipher_text = "awbix ildxz kolf a dkzeplld afu zbjjbfm lf bj bz a rwkx iajxpobwwap zdlgbfm a ellgae. jex iajxpobwwap ykxzjblfz awbix afu zex audbjz jl exp ikppxfj buxfjbjt ipbzbz, ildolkfuxu rt exp bfarbwbjt jl pxdxdrxp a olxd. rxnlpx ipahwbfm ahat, jex iajxpobwwap jxwwz awbix jeaj lfx zbux ln jex dkzeplld hbww dagx exp jawwxp afu jex ljexp zbux hbww dagx exp zelpjxp. zex rpxagz lnn jhl obxixz npld jex dkzeplld. lfx zbux dagxz exp zepbfg zdawwxp jeaf xcxp, hebwx afljexp iakzxz exp fxig jl mplh ebme bfjl jex jpxxz, hexpx a obmxlf dbzjagxz exp nlp a zxpoxfj. hbje zldx xnnlpj, awbix rpbfmz expzxwn raig jl exp kzkaw exbmej. zex zjkdrwxz kolf a zdaww xzjajx afu kzxz jex dkzeplld jl pxaie a dlpx aooplopbajx exbmej."
english_frequency = {
    'A': 8.2, 'B': 1.5, 'C': 2.8, 'D': 4.3, 'E': 13.0, 'F': 2.2, 'G': 2.0, 'H': 6.1, 'I': 7.0, 'J': 0.2, 'K': 0.8, 'L': 4.0, 'M': 2.4, 'N': 6.7, 'O': 7.5, 'P': 1.9, 'Q': 0.1, 'R': 6.0, 'S': 6.3, 'T': 9.1, 'U': 2.8, 'V': 1.0, 'W': 2.4, 'X': 0.2, 'Y': 2.0, 'Z': 0.1
}

def clean_text(text):
    cleaned_text = ""
    for char in text:
        if char.isalpha():
            cleaned_text += char.upper()
        else:
            cleaned_text += ' '
    return cleaned_text

def frequency_analysis(cipher_text):
    frequency = {}
    for x in range(26):
        c = 65 + x
        frequency[chr(c)] = 0
    for char in cipher_text:
        if char == ' ': continue
        if char in frequency:
            frequency[char] += 1

    frequency = dict(sorted(frequency.items(), key=lambda item: item[1], reverse=True))
    print("Frequency:\n", frequency)
    return frequency

def decrypt(ciphertext, key):
    plaintext = ""
    for i in range(len(ciphertext)):
        char = ciphertext[i]
        plaintext += key[char]
    return plaintext

cipher_text = clean_text(cipher_text)
print("Cleaned Text:", cipher_text)
frequency = frequency_analysis(cipher_text)
english_frequency = dict(sorted(english_frequency.items(), key=lambda item: item[1], reverse=True))
key= {}
cipher_text= cipher_text.replace('A','a')
cipher_text= cipher_text.replace('F','n')
cipher_text= cipher_text.replace('U','d')
cipher_text= cipher_text.replace('J','t')
cipher_text= cipher_text.replace('Z','s')
cipher_text= cipher_text.replace('L','o')
cipher_text= cipher_text.replace('M','g')
cipher_text= cipher_text.replace('T','y')
cipher_text= cipher_text.replace('X','e')
cipher_text= cipher_text.replace('N','f')
cipher_text= cipher_text.replace('B','i')
cipher_text= cipher_text.replace('R','b')
cipher_text= cipher_text.replace('P','r')
cipher_text= cipher_text.replace('E','h')
cipher_text= cipher_text.replace('G','k')
cipher_text= cipher_text.replace('D','m')
cipher_text= cipher_text.replace('W','l')
cipher_text= cipher_text.replace('K','u')
cipher_text= cipher_text.replace('O','p')
cipher_text= cipher_text.replace('Y','q')
cipher_text= cipher_text.replace('I','c')
cipher_text= cipher_text.replace('H','w')
cipher_text= cipher_text.replace('C','v')
print(cipher_text)
for x in frequency:
    print("Decrypt for", x)
    print()
    for c in english_frequency:
        #replace x with c in cipher text and print c in a different color in the terminal
        cipher_text = cipher_text.replace(x, c.lower())
        print(cipher_text)
        str=input("Do you accept this substitution with "+c+"? (y/n)")
        if str == "y":
            key[x] = c
            english_frequency.pop(c)
            break
        else:
            cipher_text = cipher_text.replace(c.lower(), x)
        print()

        
