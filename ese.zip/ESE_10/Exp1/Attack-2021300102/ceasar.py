# brute force attack on ceasar cipher

ciphertext = "KHOORRQDP"

def decrypt(ciphertext, key):
    plaintext = ""
    for i in range(len(ciphertext)):
        char = ciphertext[i]
        plaintext += chr((ord(char) - key - 65) % 26 + 65)
    return plaintext

def brute_force(ciphertext):
    for key in range(26):
        print("Key:", key, "Plaintext:", decrypt(ciphertext, key))

brute_force(ciphertext)
