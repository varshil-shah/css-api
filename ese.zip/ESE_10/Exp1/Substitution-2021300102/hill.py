#hill cypher
import numpy as np
key = "GYBNQKURP"
plaintext = "ALICEWASBEGINNINGTOGETVERYTIREDOFSITTINGBYHERSISTERONTHEBANKANDOFHAVINGNOTHINGTODOONCEORTWICESHEHADPEEPEDINTOBOOKHERSISTERWASREADINGBUTITHADNOPICTURESORCONVERSATIONSINITANDWHATISTHEUSEOFABOOKTHOUGHTALICEWITHOUTPICTURESORCONVERSATIONSOSHEWASCONSIDERINGINHEROWNMINDASWELLASSHECOULDFORTHEHOTDAYMADEHERFEELVERYSLEEPYANDSTUPIDWHETHERTHEPLEASUREOFMAKINGADAISYCHAINWOULDBEWORTHTHETROUBLEOFGETTINGUPANDPICKINGTHEDAISIESWHENSUDDENLYAWHITERABBITWITHPINKEYESRANCLOSEBYHERTHEREWASNOTHINGSOVERTHEEARTHHOWFUNNYITLLSEEMTOCOMEOUTAMONGTHEPEOPLETHATWALKWITHTHEIRHEADSDOWNWARDTHEANTIPATHIESITHINKSHEWASRATHERGLADTHEREWASNOONELISTENINGTHISTIMEASITDIDNTSOUNDATALLTHERIGHTWORDBUTISHALLHAVETOASKTHEMWHATTHENAMEOFTHECOUNTRYISYOUKNOWPLEASEMAAMISTHISNEWZEALANDORAUSTRALIAANDSHECURTSYEDSHEWASDOZINGOFFHADJUSTBEGUNTOBUZZWHENFINALLYSHEFOUNDHERSELFUPONAHEAPOFSTICKSANDDRYLEAVESANDTHEFALLWASOVERALICEWASNOTABITHURTANDSHESPRANGTOHERFEETINAMOMENTSHELOOKEDUPBUTITWASALLDARKOVERHEADBEFOREHERWASANOTHERLONGPASSAGEANDTHEWHITERABBITWASSTILLINSIGHTHURRYINGDOWNITTHEREWASNOTAMOMENTTOBELOSTAWAYWENTALICELIKETHEWINDANDWASJUSTINTIMETOHEARITSAYASITTURNEDACORNEROHMYEARSANDWHISKERSHOWLATEITSGETTINGSHEWASCLOSEBEHINDITWHENSHETURNEDTHECORNERBUTTHERABBITWASNONOLOSTLONGDOWNONONESIDEANDUPTHEOTHERSHECOULDNTPUTALICETHATSOUNDEDALLTHEWONDERSABOUTGETTINGOUTOFTHEWORLDINTHESTRANGEHALLS"
def get_freq(text):
    freq = {}
    for letter in text:
        if letter in freq:
            freq[letter] += 1
        else:
            freq[letter] = 1
    #sort by frequency
    freq = dict(sorted(freq.items(), key=lambda item: item[1], reverse=True))
    print(freq)
def generate_key_matrix(key):
    matrix = []
    for i in range(3):
        matrix.append([])
        for j in range(3):
            matrix[i].append(ord(key[i*3+j]) - 65)
    print(matrix)
    return matrix

matrix=generate_key_matrix(key)

def get_x(determinant):
    for i in range(26):
        if (determinant * i) % 26 == 1:
            return i

def invert_matrix(matrix):
    determinant = matrix[0][0] * matrix[1][1] * matrix[2][2] + matrix[0][1] * matrix[1][2] * matrix[2][0] + matrix[0][2] * matrix[1][0] * matrix[2][1] - matrix[0][2] * matrix[1][1] * matrix[2][0] - matrix[0][1] * matrix[1][0] * matrix[2][2] - matrix[0][0] * matrix[1][2] * matrix[2][1]
    numpy_matrix = np.array(matrix)
    inverse_matrix = np.linalg.inv(numpy_matrix)
    inverse_matrix = np.round(inverse_matrix * determinant)
    inverse_matrix = inverse_matrix.astype(int)
    x = get_x(determinant)
    for i in range(3):
        for j in range(3):
            inverse_matrix[i][j] = (inverse_matrix[i][j] * x) % 26
    return inverse_matrix

def encrypt(plaintext, key_matrix):
    ciphertext = ""
    plaintext = list(plaintext)
    if len(plaintext) % 3 != 0:
        for i in range(3 - len(plaintext) % 3):
            plaintext.append("X")
    i = 0
    while i < len(plaintext):
        x = [ord(plaintext[i]) - 65, ord(plaintext[i+1]) - 65, ord(plaintext[i+2]) - 65]
        y = [0, 0, 0]
        for j in range(3):
            for k in range(3):
                y[j] += key_matrix[j][k] * x[k]
            y[j] %= 26
        for j in range(3):
            ciphertext += chr(y[j] + 65)
        i += 3
    return ciphertext

def decrypt(ciphertext, key_matrix):
    plaintext = ""
    ciphertext = list(ciphertext)
    i = 0
    inverse_matrix = invert_matrix(key_matrix)
    while i < len(ciphertext):
        x = [0, 0, 0]
        y = [ord(ciphertext[i]) - 65, ord(ciphertext[i+1]) - 65, ord(ciphertext[i+2]) - 65]
        for j in range(3):
            for k in range(3):
                x[j] += inverse_matrix[j][k] * y[k]
            x[j] %= 26
        for j in range(3):
            plaintext += chr(x[j] + 65)
        i += 3
    return plaintext

ciphertext = encrypt(plaintext, matrix)
print("Plaintext:", plaintext)
print("Ciphertext:", ciphertext)
print("Decrypted:", decrypt(ciphertext, matrix))

get_freq(ciphertext)