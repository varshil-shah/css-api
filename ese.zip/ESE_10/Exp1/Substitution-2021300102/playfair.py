#Playfair Cypher

key="UNITED"
plaintext="ALICEWASBEGINNINGTOGETVERYTIREDOFSITTINGBYHERSISTERONTHEBANKANDOFHAVINGNOTHINGTODOONCEORTWICESHEHADPEEPEDINTOBOOKHERSISTERWASREADINGBUTITHADNOPICTURESORCONVERSATIONSINITANDWHATISTHEUSEOFABOOKTHOUGHTALICEWITHOUTPICTURESORCONVERSATIONSOSHEWASCONSIDERINGINHEROWNMINDASWELLASSHECOULDFORTHEHOTDAYMADEHERFEELVERYSLEEPYANDSTUPIDWHETHERTHEPLEASUREOFMAKINGADAISYCHAINWOULDBEWORTHTHETROUBLEOFGETTINGUPANDPICKINGTHEDAISIESWHENSUDDENLYAWHITERABBITWITHPINKEYESRANCLOSEBYHERTHEREWASNOTHINGSOVERTHEEARTHHOWFUNNYITLLSEEMTOCOMEOUTAMONGTHEPEOPLETHATWALKWITHTHEIRHEADSDOWNWARDTHEANTIPATHIESITHINKSHEWASRATHERGLADTHEREWASNOONELISTENINGTHISTIMEASITDIDNTSOUNDATALLTHERIGHTWORDBUTISHALLHAVETOASKTHEMWHATTHENAMEOFTHECOUNTRYISYOUKNOWPLEASEMAAMISTHISNEWZEALANDORAUSTRALIAANDSHECURTSYEDSHEWASDOZINGOFFHADJUSTBEGUNTOBUZZWHENFINALLYSHEFOUNDHERSELFUPONAHEAPOFSTICKSANDDRYLEAVESANDTHEFALLWASOVERALICEWASNOTABITHURTANDSHESPRANGTOHERFEETINAMOMENTSHELOOKEDUPBUTITWASALLDARKOVERHEADBEFOREHERWASANOTHERLONGPASSAGEANDTHEWHITERABBITWASSTILLINSIGHTHURRYINGDOWNITTHEREWASNOTAMOMENTTOBELOSTAWAYWENTALICELIKETHEWINDANDWASJUSTINTIMETOHEARITSAYASITTURNEDACORNEROHMYEARSANDWHISKERSHOWLATEITSGETTINGSHEWASCLOSEBEHINDITWHENSHETURNEDTHECORNERBUTTHERABBITWASNONOLOSTLONGDOWNONONESIDEANDUPTHEOTHERSHECOULDNTPUTALICETHATSOUNDEDALLTHEWONDERSABOUTGETTINGOUTOFTHEWORLDINTHESTRANGEHALLS"

def generate_key_matrix(key):
    key_matrix = []
    key = key.upper()
    key = key.replace("J", "I")
    for i in key:
        if i not in key_matrix:
            key_matrix.append(i)
    alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ"
    for i in alphabet:
        if i not in key_matrix:
            key_matrix.append(i)
    key_matrix = [key_matrix[i:i+5] for i in range(0, 25, 5)]
    return key_matrix

def print_matrix(matrix):
    for i in range(5):
        for j in range(5):
            print(matrix[i][j], end=" ")
        print()

def find_position(key_matrix, char):
    x, y = 0, 0
    for i in range(5):
        for j in range(5):
            if key_matrix[i][j] == char:
                x, y = i, j
    return x, y

def row_rule(x, y, key_matrix):
    return key_matrix[x][(y+1)%5]

def column_rule(x, y, key_matrix):
    return key_matrix[(x+1)%5][y]

def rectangle_rule(x, y,key_matrix):
    return key_matrix[x][y]

matrix = generate_key_matrix(key)
print_matrix(matrix)
def encrypt(plaintext,key_matrix):
    plaintext = plaintext.replace("J", "I")
    plaintext = list(plaintext)
    i = 0
    while i < len(plaintext)- 1:
        if plaintext[i] == plaintext[i+1]:
            plaintext.insert(i+1, "X")
        i += 2
    if len(plaintext) % 2 != 0:
        plaintext.append("X")
    print(plaintext)
    i = 0
    while i < len(plaintext):
        x1, y1 = find_position(key_matrix, plaintext[i])
        x2, y2 = find_position(key_matrix, plaintext[i+1])
        if x1 == x2:
            plaintext[i] = row_rule(x1, y1, key_matrix)
            plaintext[i+1] = row_rule(x2, y2, key_matrix)
        elif y1 == y2:
            plaintext[i] = column_rule(x1, y1, key_matrix)
            plaintext[i+1] = column_rule(x2, y2, key_matrix)
        else:
            plaintext[i] = rectangle_rule(x1, y2, key_matrix)
            plaintext[i+1] = rectangle_rule(x2, y1, key_matrix)
        i += 2
    return "".join(plaintext)

def decrypt(ciphertext,key_matrix):
    i=0
    while i<len(ciphertext):
        x1,y1=find_position(key_matrix,ciphertext[i])
        x2,y2=find_position(key_matrix,ciphertext[i+1])
        if x1==x2:
            ciphertext[i]=key_matrix[x1][(y1-1)%5]
            ciphertext[i+1]=key_matrix[x2][(y2-1)%5]
        elif y1==y2:
            ciphertext[i]=key_matrix[(x1-1)%5][y1]
            ciphertext[i+1]=key_matrix[(x2-1)%5][y2]
        else:
            ciphertext[i]=key_matrix[x1][y2]
            ciphertext[i+1]=key_matrix[x2][y1]
        i+=2

    return "".join(ciphertext)
def get_freq(text):
    freq = {}
    for letter in text:
        if letter in freq:
            freq[letter] += 1
        else:
            freq[letter] = 1
    #sort by frequency
    freq = dict(sorted(freq.items(), key=lambda item: item[1], reverse=True))
    print(freq)
ciphertext=encrypt(plaintext,matrix)
print("Plaintext:",plaintext)
print("Ciphertext:",ciphertext)
print("Decrypted:",decrypt(list(ciphertext),matrix) )

get_freq(ciphertext)