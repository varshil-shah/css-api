vigenere = {'R': 95, 'Y': 81, 'M': 80, 'C': 80, 'F': 77, 'L': 75, 'Q': 74, 'S': 63, 'E': 60, 'G': 59, 'I': 57, 'X': 55, 'P': 51, 'D': 46, 'U': 41, 'K': 40, 'B': 40, 'A': 39, 'Z': 36, 'O': 35, 'W': 34, 'J': 29, 'N': 26, 'V': 22, 'T': 18, 'H': 18}
playfair = {'N': 142, 'U': 109, 'T': 98, 'P': 94, 'E': 82, 'F': 75, 'H': 69, 'C': 67, 'M': 67, 'S': 60, 'I': 53, 'R': 46, 'A': 44, 'Q': 41, 'B': 37, 'Y': 34, 'L': 34, 'D': 33, 'O': 32, 'Z': 31, 'V': 31, 'G': 27, 'K': 24, 'W': 16, 'X': 8}
monoalphabetic = {'T': 155, 'Z': 132, 'Q': 112, 'F': 101, 'G': 97, 'I': 95, 'L': 94, 'O': 91, 'K': 69, 'R': 58, 'S': 52, 'V': 48, 'X': 40, 'U': 31, 'W': 25, 'E': 24, 'H': 21, 'N': 19, 'Y': 19, 'D': 17, 'A': 15, 'C': 10, 'M': 4, 'P': 2}
hill = {'N': 68, 'J': 65, 'D': 60, 'V': 58, 'M': 56, 'U': 56, 'X': 56, 'W': 55, 'P': 55, 'I': 54, 'T': 54, 'Y': 53, 'A': 51, 'Q': 50, 'G': 50, 'K': 50, 'H': 49, 'L': 49, 'C': 49, 'O': 48, 'Z': 45, 'R': 44, 'B': 44, 'E': 42, 'F': 37, 'S': 34}
caesar = {'H': 155, 'W': 132, 'D': 112, 'Q': 101, 'R': 97, 'K': 95, 'V': 94, 'L': 91, 'U': 69, 'G': 58, 'O': 52, 'Z': 48, 'X': 40, 'J': 31, 'E': 25, 'F': 24, 'S': 21, 'B': 19, 'I': 19, 'P': 17, 'N': 15, 'Y': 10, 'C': 4, 'M': 2}
plaintext = {'E': 155, 'T': 132, 'A': 112, 'N': 101, 'O': 97, 'H': 95, 'S': 94, 'I': 91, 'R': 69, 'D': 58, 'L': 52, 'W': 48, 'U': 40, 'G': 31, 'B': 25, 'C': 24, 'P': 21, 'Y': 19, 'F': 19, 'M': 17, 'K': 15, 'V': 10, 'Z': 4, 'J': 2}

#visualize the frequency of each letter in the text as a linechart, but x axis is labelled by numers 0 through 25

import matplotlib.pyplot as plt

def normalize(data):
    #max freqy is always the first element
    max_freq = list(data.values())[0]
    for key in data:
        data[key] = data[key] / max_freq * 100
    return data

def visualize(data, title):
    data = normalize(data)
    plt.plot(list(data.values()))
    plt.xticks([i for i in range(26)])
    plt.title(title)
#visulainze all 5 dictionaries on the same chart
visualize(vigenere, "Vigenere")
visualize(playfair, "Playfair")
visualize(monoalphabetic, "Monoalphabetic")
visualize(hill, "Hill")
visualize(caesar, "Caesar")
visualize(plaintext, "Plaintext")
plt.legend(["Vigenere", "Playfair", "Monoalphabetic", "Hill", "Caesar", "Plaintext"])
plt.show()

