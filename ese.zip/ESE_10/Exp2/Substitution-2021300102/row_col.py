#row column transposition cipher

plaintext="ALICEWASBEGINNINGTOGETVERYTIREDOFSITTINGBYHERSISTERONTHEBANKANDOFHAVINGNOTHINGTODOONCEORTWICESHEHADPEEPEDINTOBOOKHERSISTERWASREADINGBUTITHADNOPICTURESORCONVERSATIONSINITANDWHATISTHEUSEOFABOOKTHOUGHTALICEWITHOUTPICTURESORCONVERSATIONSOSHEWASCONSIDERINGINHEROWNMINDASWELLASSHECOULDFORTHEHOTDAYMADEHERFEELVERYSLEEPYANDSTUPIDWHETHERTHEPLEASUREOFMAKINGADAISYCHAINWOULDBEWORTHTHETROUBLEOFGETTINGUPANDPICKINGTHEDAISIESWHENSUDDENLYAWHITERABBITWITHPINKEYESRANCLOSEBYHERTHEREWASNOTHINGSOVERTHEEARTHHOWFUNNYITLLSEEMTOCOMEOUTAMONGTHEPEOPLETHATWALKWITHTHEIRHEADSDOWNWARDTHEANTIPATHIESITHINKSHEWASRATHERGLADTHEREWASNOONELISTENINGTHISTIMEASITDIDNTSOUNDATALLTHERIGHTWORDBUTISHALLHAVETOASKTHEMWHATTHENAMEOFTHECOUNTRYISYOUKNOWPLEASEMAAMISTHISNEWZEALANDORAUSTRALIAANDSHECURTSYEDSHEWASDOZINGOFFHADJUSTBEGUNTOBUZZWHENFINALLYSHEFOUNDHERSELFUPONAHEAPOFSTICKSANDDRYLEAVESANDTHEFALLWASOVERALICEWASNOTABITHURTANDSHESPRANGTOHERFEETINAMOMENTSHELOOKEDUPBUTITWASALLDARKOVERHEADBEFOREHERWASANOTHERLONGPASSAGEANDTHEWHITERABBITWASSTILLINSIGHTHURRYINGDOWNITTHEREWASNOTAMOMENTTOBELOSTAWAYWENTALICELIKETHEWINDANDWASJUSTINTIMETOHEARITSAYASITTURNEDACORNEROHMYEARSANDWHISKERSHOWLATEITSGETTINGSHEWASCLOSEBEHINDITWHENSHETURNEDTHECORNERBUTTHERABBITWASNONOLOSTLONGDOWNONONESIDEANDUPTHEOTHERSHECOULDNTPUTALICETHATSOUNDEDALLTHEWONDERSABOUTGETTINGOUTOFTHEWORLDINTHESTRANGEHALLS"
col=4
key="4312"

def encrypt(plaintext,key,col):
    while len(plaintext)%len(key)!=0:
        plaintext+="X"

    matrix=[]
    rows=len(plaintext)//col
    for i in range(0,len(plaintext),col):
        matrix.append(list(plaintext[i:i+col]))
    ciphertext=""
    for i in key:
        index=int(i)-1
        for j in range(rows):
            ciphertext+=matrix[j][index]
    return ciphertext


def decrypt(ciphertext,key,col):
    #matrix of dimensions rows x col
    row=len(ciphertext)//col
    matrix=[]
    for i in range(row):
        matrix.append(['']*col)
    k=0
    for i in range(col):
        for j in range(row):
            matrix[j][i]=ciphertext[k]
            k+=1
    
    dict={}
    for i in range(len(key)):
        dict[int(key[i])-1]=i
    new_matrix=[]
    for i in range(col):
        index=dict[i]
        row_arr=[]
        for j in range(row):
            row_arr.append(matrix[j][index])
        new_matrix.append(row_arr)
    plain=""
    for i in range(len(new_matrix[0])):
        for j in range(len(new_matrix)):
            plain+=new_matrix[j][i]
    return plain
    
def get_freq(text):
    freq = {}
    for letter in text:
        if letter in freq:
            freq[letter] += 1
        else:
            freq[letter] = 1
    #sort by frequency
    freq = dict(sorted(freq.items(), key=lambda item: item[1], reverse=True))
    print(freq)

ciphertext=encrypt(plaintext,key,col)
print("Plaintext:",plaintext)
print("Ciphertext:",ciphertext)
print("Decrypted:",decrypt(ciphertext,key,col))

get_freq(ciphertext)
