rail_fence = {'E': 155, 'T': 132, 'A': 112, 'N': 101, 'O': 97, 'H': 95, 'S': 94, 'I': 91, 'R': 69, 'D': 58, 'L': 52, 'W': 48, 'U': 40, 'G': 31, 'B': 25, 'C': 24, 'P': 21, 'F': 19, 'Y': 19, 'M': 17, 'K': 15, 'V': 10, 'Z': 4, 'J': 2}
row_col = {'E': 155, 'T': 132, 'A': 112, 'N': 101, 'O': 97, 'H': 95, 'S': 94, 'I': 91, 'R': 69, 'D': 58, 'L': 52, 'W': 48, 'U': 40, 'G': 31, 'B': 25, 'C': 24, 'P': 21, 'F': 19, 'Y': 19, 'M': 17, 'K': 15, 'V': 10, 'Z': 4, 'J': 2, 'X': 1}
import matplotlib.pyplot as plt

def normalize(data):
    #max freqy is always the first element
    max_freq = list(data.values())[0]
    for key in data:
        data[key] = data[key] / max_freq * 100
    return data

def visualize(data, title):
    data = normalize(data)
    plt.plot(list(data.values()))
    plt.xticks([i for i in range(26)])
    plt.title(title)

visualize(rail_fence, "Rail Fence")
visualize(row_col, "Row Column")
plt.legend(["Rail Fence", "Row Column"])
plt.show()

#Observations
'''
The frequency of the letters in the Rail Fence and Row Column ciphers are the same, which is equal to their frequency in the plaintext.
This is because both ciphers do not change the frequency of the letters in the plaintext. Instead, they rearrange the letters in the plaintext to create the ciphertext.
Hence frequency analysis is not effective in breaking these ciphers.
But they are vulnerable to other attacks like brute force or known plaintext attacks.
The brute force attack involves trying all possible keys to decrypt the ciphertext. 
This has been demonostrated in /Attack-2021300102/rail_fence.py and /Attack-2021300102/row_col.py

Attacking the row column cipher is more difficult than attacking the rail fence cipher because the row column cipher has more possible keys, as we need to generate all possible permutations of the key
as well as the number of columns in the matrix.
In the rail fence cipher, the key is the number of rows in the rail fence, which is much smaller than the number of possible keys in the row column cipher.
'''