def decryptRailFence(ciphertext, key):
    rail = [['*' for i in range(len(ciphertext))]
            for j in range(key)]
    direction_down = None
    col = 0
    row = 0

    for i in range(len(ciphertext)):
        if row == 0:
            direction_down = True
        if row == key - 1:
            direction_down = False
        rail[row][col] = 'mkr'
        col += 1
        if direction_down:
            row += 1
        else:
            row -= 1
    idx = 0
    for i in range(key):
        for j in range(len(ciphertext)):
            if ((rail[i][j] == 'mkr') and
                    (idx < len(ciphertext))):
                rail[i][j] = ciphertext[idx]
                idx += 1

    plaintext = []
    col = 0
    row = 0
    for i in range(len(ciphertext)):
        if row == 0:
            direction_down = True
        if row == key - 1:
            direction_down = False
        plaintext.append(rail[row][col])
        col += 1

        if direction_down:
            row += 1
        else:
            row -= 1
    return "".join(plaintext)


def brute_force(ciphertext):
    for i in range(2, len(ciphertext)):
        print("Key:",i)
        print("Plaintext:",decryptRailFence(ciphertext,i))
        print("")

ciphertext = "HOMELOALN"

print("Ciphertext:",ciphertext)
brute_force(ciphertext)


