def decrypt(ciphertext,key,col):
    #matrix of dimensions rows x col
    row=len(ciphertext)//col
    matrix=[]
    for i in range(row):
        matrix.append(['']*col)
    k=0
    for i in range(col):
        for j in range(row):
            matrix[j][i]=ciphertext[k]
            k+=1
    
    dict={}
    for i in range(len(key)):
        dict[int(key[i])-1]=i
    new_matrix=[]
    for i in range(col):
        index=dict[i]
        row_arr=[]
        for j in range(row):
            row_arr.append(matrix[j][index])
        new_matrix.append(row_arr)
    plain=""
    for i in range(len(new_matrix[0])):
        for j in range(len(new_matrix)):
            plain+=new_matrix[j][i]
    return plain

def bruteforce(ciphertext,col):
    #generate permutations of columns '1234'
    from itertools import permutations
    keystr=""
    for i in range(1,col+1):
        keystr+=str(i)
    perms=permutations(keystr)
    for perm in perms:
        key="".join(perm)
        print("Key:",key)
        print("Plaintext:",decrypt(ciphertext,key,col))
        print()

ciphertext="LAXLNXHOMEOX"
col=4

print("Ciphertext:",ciphertext)
bruteforce(ciphertext,col)
